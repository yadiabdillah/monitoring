<?php
Class Formulir extends CI_Controller{
    
    function __construct() {
        parent::__construct();
        $this->load->model('model_formulir');
    }
    
    function index(){
        if ($this->session->userdata("status")=="login"){
            $this->load->view('formulir/form_input');
        } else {
                redirect(base_url('index.php/welcome'));
            }
    }
    
    function save(){
        if ($this->session->userdata("status")=="login"){
            if(isset($_POST['submit'])){
                $this->model_formulir->save();
                redirect('Formulir');
            } else {
                $this->load->view('formulir/form_input');
            }
        } else {
            redirect(base_url('index.php/welcome'));
        }
    }
    
    function view(){
        if ($this->session->userdata("status")=="login"){
            $data['record'] = $this->model_formulir->view();
            $this->load->view('formulir/view', $data);
        } else {
            redirect(base_url('index.php/welcome'));
        }
    }
    
    
    function edit(){
        if ($this->session->userdata("status")=="login"){
            if(isset($_POST['submit'])){
                $this->model_formulir->edit();
                redirect('formulir/view');
            } else {
                $id = $this->uri->segment(3);
                $data['record'] = $this->model_formulir->get_one($id)->row_array();

                $this->load->view('formulir/form_edit', $data);
            }
        } else {
            redirect(base_url('index.php/welcome'));
        }
    }
    
    function check(){
        if ($this->session->userdata("status")=="login"){
            $id = $this->uri->segment(3);
            $data['record'] = $this->model_formulir->get_one($id)->row_array();
            
            $this->load->view('formulir/form_check', $data);
        } else {
            redirect(base_url('index.php/welcome'));
        }
        
    }
    
    function delete(){
        if ($this->session->userdata("status")=="login"){
            $id = $this->uri->segment(3);
            $this->model_sertifikat->delete($id);
            redirect('formulir/view');
        } else {
            redirect(base_url('index.php/welcome'));
        }
    }
    
}