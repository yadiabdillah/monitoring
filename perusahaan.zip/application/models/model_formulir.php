<?php

class model_formulir extends CI_Model{
    
    
    function save(){
        $data = array('no_formulir'=> '', 
                'nama_direktur'=> $this->input->post('nama_direktur'),
                'penanggung_jwb'=> $this->input->post('penanggung_jwb'),
                'tmp_lahir'=> $this->input->post('tmp_lahir'),
                'tgl_lahir'=> $this->input->post('tgl_lahir'),
                'alamat'=> $this->input->post('alamat'),
                'pekerjaan'=> $this->input->post('pekerjaan'),
                'nik'=> $this->input->post('nik'),
                'npwp'=> $this->input->post('npwp'),
                'kewarganegaraan'=> $this->input->post('kewarganegaraan'),
                'no_telp_direktur'=> $this->input->post('no_telp_direktur'),
                'nama_perusahaan'=> $this->input->post('nama_perusahaan'),
                'alamat_perusahaan'=> $this->input->post('alamat_perusahaan'),
                'perusahaan'=> $this->input->post('perusahaan'),
                'email_perusahaan'=> $this->input->post('email_perusahaan'),
                'no_telp_perusahaan'=> $this->input->post('no_telp_perusahaan'),
                'modal_dasar'=> $this->input->post('modal_dasar'),
                'modal_ditempatkan'=> $this->input->post('modal_ditempatkan'),
                'bidang_usaha'=> $this->input->post('bidang_usaha'),
                'kegiatan_usaha'=> $this->input->post('kegiatan_usaha'),
                'komposisi_saham'=> $this->input->post('komposisi_saham'),
                'direktur_perusahaan'=> $this->input->post('direktur_perusahaan'),
                'wakil_direktur'=> $this->input->post('wakil_direktur'),
                'komisaris1'=> $this->input->post('komisaris1'),
                'komisaris2'=> $this->input->post('komisaris2')
            );
            $this->db->insert('formulir_pp', $data);
    }
    
    function view(){
        $query = "SELECT * from formulir_pp";
        return $this->db->query($query);
    }
    
    function get_one($id){
        $query = "SELECT * from formulir_pp where no_formulir =".$id;
        return $this->db->query($query);
    }
    
    function edit(){
        $data = array(
                'nama_direktur'=> $this->input->post('nama_direktur'),
                'penanggung_jwb'=> $this->input->post('penanggung_jwb'),
                'tmp_lahir'=> $this->input->post('tmp_lahir'),
                'tgl_lahir'=> $this->input->post('tgl_lahir'),
                'alamat'=> $this->input->post('alamat'),
                'pekerjaan'=> $this->input->post('pekerjaan'),
                'nik'=> $this->input->post('nik'),
                'npwp'=> $this->input->post('npwp'),
                'kewarganegaraan'=> $this->input->post('kewarganegaraan'),
                'no_telp_direktur'=> $this->input->post('no_telp_direktur'),
                'nama_perusahaan'=> $this->input->post('nama_perusahaan'),
                'alamat_perusahaan'=> $this->input->post('alamat_perusahaan'),
                'perusahaan'=> $this->input->post('perusahaan'),
                'email_perusahaan'=> $this->input->post('email_perusahaan'),
                'no_telp_perusahaan'=> $this->input->post('no_telp_perusahaan'),
                'modal_dasar'=> $this->input->post('modal_dasar'),
                'modal_ditempatkan'=> $this->input->post('modal_ditempatkan'),
                'bidang_usaha'=> $this->input->post('bidang_usaha'),
                'kegiatan_usaha'=> $this->input->post('kegiatan_usaha'),
                'komposisi_saham'=> $this->input->post('komposisi_saham'),
                'direktur_perusahaan'=> $this->input->post('direktur_perusahaan'),
                'wakil_direktur'=> $this->input->post('wakil_direktur'),
                'komisaris1'=> $this->input->post('komisaris1'),
                'komisaris2'=> $this->input->post('komisaris2')
            );
        $this->db->where('no_formulir', $this->input->post('no_formulir'));
        $this->db->update('formulir_pp', $data);
    }
    
    function delete($id){
        $this->db->where('no_formulir', $id);
        $this->db->delete('formulir');
    }
}

