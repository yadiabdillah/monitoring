<?php

class model_sertifikat extends CI_Model{
    
    
    function save(){
        $data = array('id_sertikikat'=> '', 
                'nama_penjual'=> $this->input->post('nama_penjual'),
                'tempat_lahir_penjual'=> $this->input->post('tempat_lahir_penjual'),
                'tgl_lahir_penjual'=> $this->input->post('tgl_lahir_penjual'),
                'alamat_penjual'=> $this->input->post('alamat_penjual'),
                'pekerjaan_penjual'=> $this->input->post('pekerjaan_penjual'),
                'nik_penjual'=> $this->input->post('nik_penjual'),
                'npwp_penjual'=> $this->input->post('npwp_penjual'),
                'nama_pasangan_penjual'=> $this->input->post('nama_pasangan_penjual'),
                'tmp_lahir_pasangan'=> $this->input->post('tmp_lahir_pasangan'),
                'tgl_lahir_pasangan'=> $this->input->post('tgl_lahir_pasangan'),
                'alamat_pasangan'=> $this->input->post('alamat_pasangan'),
                'pekerjaan_pasangan'=> $this->input->post('pekerjaan_pasangan'),
                'nik_pasangan'=> $this->input->post('nik_pasangan'),
                'npwp_pasangan'=> $this->input->post('npwp_pasangan'),
                'no_sertifikat'=> $this->input->post('no_sertifikat'),
                'no_surat_ukur'=> $this->input->post('no_surat_ukur'),
                'luas_tanah'=> $this->input->post('luas_tanah'),
                'luas_bangunan'=> $this->input->post('luas_bangunan'),
                'tgl_surat_ukur'=> $this->input->post('tgl_surat_ukur'),
                'no_id_bdg_tnh'=> $this->input->post('no_id_bdg_tnh'),
                'alamat_objek'=> $this->input->post('alamat_objek'),
                'no_objek_pajak'=> $this->input->post('no_objek_pajak'),
                'harga_transaksi'=> $this->input->post('harga_transaksi')
            );
            $this->db->insert('sertifikat', $data);
    }
    
    function view(){
        $query = "SELECT * from sertifikat";
        return $this->db->query($query);
    }
    
    function get_one($id){
        $query = "SELECT * from sertifikat where id_sertikikat =".$id;
        return $this->db->query($query);
    }
    
    function edit(){
        $data = array(
                'nama_penjual'=> $this->input->post('nama_penjual'),
                'tempat_lahir_penjual'=> $this->input->post('tempat_lahir_penjual'),
                'tgl_lahir_penjual'=> $this->input->post('tgl_lahir_penjual'),
                'alamat_penjual'=> $this->input->post('alamat_penjual'),
                'pekerjaan_penjual'=> $this->input->post('pekerjaan_penjual'),
                'nik_penjual'=> $this->input->post('nik_penjual'),
                'npwp_penjual'=> $this->input->post('npwp_penjual'),
                'nama_pasangan_penjual'=> $this->input->post('nama_pasangan_penjual'),
                'tmp_lahir_pasangan'=> $this->input->post('tmp_lahir_pasangan'),
                'tgl_lahir_pasangan'=> $this->input->post('tgl_lahir_pasangan'),
                'alamat_pasangan'=> $this->input->post('alamat_pasangan'),
                'pekerjaan_pasangan'=> $this->input->post('pekerjaan_pasangan'),
                'nik_pasangan'=> $this->input->post('nik_pasangan'),
                'npwp_pasangan'=> $this->input->post('npwp_pasangan'),
                'no_sertifikat'=> $this->input->post('no_sertifikat'),
                'no_surat_ukur'=> $this->input->post('no_surat_ukur'),
                'luas_tanah'=> $this->input->post('luas_tanah'),
                'luas_bangunan'=> $this->input->post('luas_bangunan'),
                'tgl_surat_ukur'=> $this->input->post('tgl_surat_ukur'),
                'no_id_bdg_tnh'=> $this->input->post('no_id_bdg_tnh'),
                'alamat_objek'=> $this->input->post('alamat_objek'),
                'no_objek_pajak'=> $this->input->post('no_objek_pajak'),
                'harga_transaksi'=> $this->input->post('harga_transaksi')
            );
        $this->db->where('id_sertikikat', $this->input->post('id_sertikikat'));
        $this->db->update('sertifikat', $data);
    }
    
    function delete($id){
        $this->db->where('id_sertikikat', $id);
        $this->db->delete('sertifikat');
    }
}

